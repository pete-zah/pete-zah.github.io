Hide Wraith
===========
A small script to delete the Wraith entry in your Addons27.db, this will hide the addon both as an available update and in the repo
